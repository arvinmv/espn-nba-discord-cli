import cli

def main():
#    discord_bot.run()
    cli.commands()

if __name__ == "__main__":
    main()